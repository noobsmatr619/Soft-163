//**************************************************************************//
// Assembler in Vusial Studio.cpp.  Usually a "C" application kicks off in	//
// main(), here we kick off in wmain(), not main() this is a unicode build  //
// (w for "wide").															//
//																			//
// This is a "C" program, and we do the input and output in "C", as doing	//
// so using assembler is a real pain.										//
//**************************************************************************//

//**************************************************************************//
// This code is copyright of Dr Nigel Barlow, lecturer in computing,		//
// University of Plymouth, UK.  email: nigel@soc.plymouth.ac.uk.			//
//																			//
// You may use, modify and distribute this (rather cack-handed in places)	//
// code subject to the following conditions:								//
//																			//
//	1:	You may not use it, or sell it, or use it in any adapted form for	//
//		financial gain, without my written premission.						//
//																			//
//	2:	You must not remove the copyright messages.							//
//																			//
//	3:	You should correct at least 10% of the typig abd spekking errirs.   //
//**************************************************************************//


#include "stdafx.h"
#include <stdlib.h>


void printChar(char c);
void printStr(char *strAddr);
void printInt(int someInt);


//**************************************************************************//
// Define some variables.  Not in assembler yet.							//
//																			//
// We have a nessage (an array of many characters), the symbol "message"	//
// represents a pointer to (contains the address of) the first character in //
// the message.																//
//																			//
// What we don't see is that "C" will always put a zero at the end of the	//
// string.																	//
//**************************************************************************//
int counter = 1;
int divCount;
int *factors;
int anItem;

int factorsSum;
char *perfectNumber = " is perfect number.";

//**************************************************************************//
// C programs usually kick off in main().  This is a unicode build, so it	//
// kicks off in wmain() (wide main).										//
//**************************************************************************//
int wmain(int argc, _TCHAR* argv[])
{

	//**********************************************************************//
	// As usual, we use "C" to do the heavy lifting and enter the numbers.	//
	//**********************************************************************//
	factors = (int*)malloc(200);
	do {



		factors[divCount] = counter;

		printf("Press 0 to continue  ");
		scanf("%d", &anItem);

	} while (anItem != 0);


	//**********************************************************************//
	// Into assembler.														//
	// All the text in green after the "//" is a comment.  Comments are		//
	// purely for us humans to leave notes for ourselves; they are ignored	//
	// by the computer.														//
	//**********************************************************************//
	__asm
	{


	next_counter:				// loop for number increment
		inc counter				// increasing the number before start as started from 0		
			mov esi, counter	
			mov divCount, esi

			loop1 :				// loop for decreasing divisor
		dec divCount
			mov eax, counter
			mov edx, 0			// keeping remainder memory free
			mov ebx, divCount
			div ebx






			cmp edx, 0		// filtering remainder 
			jz law

			idk :
		cmp divCount, 1
			jnz loop1

			// push factorsSum
			// call printInt
			// call printNewLine

			mov eax, factorsSum
			cmp counter, eax    // checking for perfect number 
			je printPerfectMessage

			back :


		mov factorsSum, 0
			jmp next_counter


			law :
		mov edi, divCount
			mov factors, edi

			// push 'f'
			// call printChar
			// push factors
			// call printInt

			add factorsSum, edi		// adding sums of factors 

			//mov edi, divCount
			//add edi, divCount
			//cmp edi, counter

			//		jz done
			//push edi 
			//call printInt
			//call printNewLine
			//push edx
			//call printInt
			//push divCount
			//call printInt
			//ping:
			// push 'n'
			// call printChar
			// push counter
			// call printInt
			// call printNewLine
			jmp idk

			//done :
			//push divCount 
			//call printInt
			//call printNewLine
			//push counter
			//call printInt
			//call printNewLine
			//jmp ping
			jmp finish


			printPerfectMessage :
		push counter
			call printInt
			push perfectNumber
			call printStr
			call printNewLine

			jmp back


					call printNewLine	
						
					jmp finish		// We need to jump past the subroutine(s) that follow
									// else the CPU will just carry on going.





	//**********************************************************************//
	// Subroutimes start here, bits of code we want to execute more than	//
	// once, or just because we want to split a compliated task into several//
	// simpler ones.														//
	//**********************************************************************//



	//**********************************************************************//
	// This subroutine just makes one new line by printing the carriage		//
	// return and line feed characters.  Do we need both for a new line?  I //
	// think so...  Nigel.													//
	//																		//
	// No parameters go in.  Nothing comes back.							//
	//**********************************************************************//
		printNewLine:
						push '\r'				// Two lines to print a char.
						call printChar

						push '\n'				// Two lines to print another char.
						call printChar

						ret					// And back to <whaerever we came from>





		//**********************************************************************//
		// Label to mark the end; do nothing, just jump here to finish.			//
		//**********************************************************************//
		finish:						// Do nothing			
	}


	//**********************************************************************//
	// Out of assembler.													//
	//**********************************************************************//
	printf("\n\npress enter to quit\n");
	char dummy[10];	     //Just in case several keys in buffer
	scanf("%c", dummy);  //pause.
	scanf("%c", dummy);  //pause.  And once more.  Something weird going on.
}



//**********************************************************************//
// Prints a single character.											//
// Push the char to be printed onto the stack; a First In Last Out		//
// data structure.  Remember, unlike C#, a char here is 1 byte in size. //
//																		//
// Parameters in: Push a single char onto the stack, as above.			//
// Returns:		  Nothing.												//
// Other issues:  Does it preserve CPU registers eax, ebx, ecx, edx,	//
//				  esi, edi etc.?  No idea (it takes us into "C", so		//
//				  assume not.											//
//**********************************************************************//
void printChar(char c)
{
	printf("%c", c);  //%c means as a char

}	// we don't seee the "ret" instruction unless you view the ".cod" listing 
	// in the "debug" folder.



//**********************************************************************//
// Print a whole string, which must end with a zero byte.				//
// it takes one parameter, which is the start address of the string.	//
//**********************************************************************//
void printStr(char *strAddr)
{
	printf("%s", strAddr);
}	// we don't seee the "ret" instruction unless you view the ".cod" listing 
	// in the "debug" folder.




//**********************************************************************//
// Prints a single integer	.											//
// Push the integer to be printed onto the stack; a First In Last Out	//
// data structure.  Remember, an integer here is 4 bytes in size.		//
//																		//
// Parameters in: push a single integer onto the stack, as above.		//
// Returns:		  Nothing.												//
// Other issues:  Does it preserve CPU registers eax, ebx, ecx, edx,	//
//				  esi, edi etc.?  No idea (it takes us into "C", so		//
//				  assume not.											//
//**********************************************************************//
void printInt(int someInt)
{
	printf("%d", someInt);
}	// we don't seee the "ret" instruction unless you view the ".cod" listing 
	// in the "debug" folder.


